﻿using ATMTECH.Entities;

namespace ATMTECH.FishingAtWork.Entities
{
    public class Configuration : BaseEntity
    {
        public const string PAGE_ADMIN = "admin.aspx";
        public const string PAGE_HOME = "default.aspx";

    }
}
