﻿using ATMTECH.Entities;

namespace ATMTECH.FishingAtWork.Entities
{
    public class EnumAchievement : BaseEnumeration
    {

        
    }
}
