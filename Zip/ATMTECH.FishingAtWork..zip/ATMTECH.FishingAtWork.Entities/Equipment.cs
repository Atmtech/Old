﻿using ATMTECH.Entities;

namespace ATMTECH.FishingAtWork.Entities
{
    public class Equipement : BaseEntity
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}
