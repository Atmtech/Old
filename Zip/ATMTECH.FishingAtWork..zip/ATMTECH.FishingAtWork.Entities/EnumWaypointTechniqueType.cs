﻿using ATMTECH.Entities;


namespace ATMTECH.FishingAtWork.Entities
{
    public class EnumWaypointTechniqueType : BaseEnumeration
    {
    }
}
