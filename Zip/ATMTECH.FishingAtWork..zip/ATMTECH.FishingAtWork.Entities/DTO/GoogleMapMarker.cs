﻿namespace ATMTECH.FishingAtWork.Entities.DTO
{
    public class GoogleMapMarker
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Information { get; set; }
        public string Icon { get; set; }
    }
}