﻿////------------------------------------------------------------------------------
//// <généré automatiquement>
////     Ce code a été généré par un outil.
////
////     Les modifications apportées à ce fichier peuvent provoquer un comportement incorrect et seront perdues si
////     le code est régénéré.
//// </généré automatiquement>
////------------------------------------------------------------------------------

//namespace ATMTECH.FishingAtWork.WebSite {
    
    
//    public partial class Shopping {
        
//        /// <summary>
//        /// Contrôle lblShopping.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblShopping;
        
//        /// <summary>
//        /// Contrôle pnlLure.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlLure;
        
//        /// <summary>
//        /// Contrôle lblLureList.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblLureList;
        
//        /// <summary>
//        /// Contrôle grdLureList.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Grille.GrilleAvance grdLureList;
//    }
//}
