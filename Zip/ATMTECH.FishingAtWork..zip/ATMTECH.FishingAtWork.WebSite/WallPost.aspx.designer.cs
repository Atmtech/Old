﻿////------------------------------------------------------------------------------
//// <généré automatiquement>
////     Ce code a été généré par un outil.
////
////     Les modifications apportées à ce fichier peuvent provoquer un comportement incorrect et seront perdues si
////     le code est régénéré.
//// </généré automatiquement>
////------------------------------------------------------------------------------

//namespace ATMTECH.FishingAtWork.WebSite {
    
    
//    public partial class WallPost {
        
//        /// <summary>
//        /// Contrôle lblWallPost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblWallPost;
        
//        /// <summary>
//        /// Contrôle pnlPostList.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlPostList;
        
//        /// <summary>
//        /// Contrôle grdLureList.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Grille.GrilleAvance grdLureList;
        
//        /// <summary>
//        /// Contrôle btnWritePost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnWritePost;
        
//        /// <summary>
//        /// Contrôle pnlWritePost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlWritePost;
        
//        /// <summary>
//        /// Contrôle lblWritePost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblWritePost;
        
//        /// <summary>
//        /// Contrôle CKEditorEditorPost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::CKEditor.NET.CKEditorControl CKEditorEditorPost;
        
//        /// <summary>
//        /// Contrôle btnSavePost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnSavePost;
        
//        /// <summary>
//        /// Contrôle btnCancelPost.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnCancelPost;
//    }
//}
