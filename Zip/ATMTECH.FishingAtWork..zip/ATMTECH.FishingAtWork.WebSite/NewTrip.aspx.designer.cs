﻿////------------------------------------------------------------------------------
//// <généré automatiquement>
////     Ce code a été généré par un outil.
////
////     Les modifications apportées à ce fichier peuvent provoquer un comportement incorrect et seront perdues si
////     le code est régénéré.
//// </généré automatiquement>
////------------------------------------------------------------------------------

//namespace ATMTECH.FishingAtWork.WebSite {
    
    
//    public partial class NewTrip {
        
//        /// <summary>
//        /// Contrôle pnlStep1.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlStep1;
        
//        /// <summary>
//        /// Contrôle lblTitleNewTrip.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblTitleNewTrip;
        
//        /// <summary>
//        /// Contrôle ddlSite.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlSite;
        
//        /// <summary>
//        /// Contrôle txtName.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtName;
        
//        /// <summary>
//        /// Contrôle txtDateStart.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.DateTextBoxAvance txtDateStart;
        
//        /// <summary>
//        /// Contrôle btnAddWayPoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnAddWayPoint;
        
//        /// <summary>
//        /// Contrôle btnCancel.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnCancel;
        
//        /// <summary>
//        /// Contrôle pnlStep2.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlStep2;
        
//        /// <summary>
//        /// Contrôle lblTitleSelect.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblTitleSelect;
        
//        /// <summary>
//        /// Contrôle googleMap.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.FishingAtWork.WebSite.UserControls.GoogleMap googleMap;
        
//        /// <summary>
//        /// Contrôle pnlStep3.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlStep3;
        
//        /// <summary>
//        /// Contrôle Label1.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label Label1;
        
//        /// <summary>
//        /// Contrôle lblCurrentWayPoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblCurrentWayPoint;
        
//        /// <summary>
//        /// Contrôle lblMaximumWayPoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblMaximumWayPoint;
        
//        /// <summary>
//        /// Contrôle ddlLure.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlLure;
        
//        /// <summary>
//        /// Contrôle ddlTechnique.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlTechnique;
        
//        /// <summary>
//        /// Contrôle ddlDeep.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlDeep;
        
//        /// <summary>
//        /// Contrôle ddlTimeStart.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlTimeStart;
        
//        /// <summary>
//        /// Contrôle ddlTimeEnd.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlTimeEnd;
        
//        /// <summary>
//        /// Contrôle txtLatitude.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtLatitude;
        
//        /// <summary>
//        /// Contrôle txtPixelX.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtPixelX;
        
//        /// <summary>
//        /// Contrôle txtLongitude.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtLongitude;
        
//        /// <summary>
//        /// Contrôle txtPixelY.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtPixelY;
        
//        /// <summary>
//        /// Contrôle btnAddWayPoint2.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnAddWayPoint2;
        
//        /// <summary>
//        /// Contrôle btnFinish.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnFinish;
        
//        /// <summary>
//        /// Contrôle pnlStep4.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlStep4;
        
//        /// <summary>
//        /// Contrôle lblResume.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblResume;
        
//        /// <summary>
//        /// Contrôle googleMapResume.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.FishingAtWork.WebSite.UserControls.GoogleMap googleMapResume;
        
//        /// <summary>
//        /// Contrôle btnFinish2.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnFinish2;
//    }
//}
