﻿////------------------------------------------------------------------------------
//// <généré automatiquement>
////     Ce code a été généré par un outil.
////
////     Les modifications apportées à ce fichier peuvent provoquer un comportement incorrect et seront perdues si
////     le code est régénéré.
//// </généré automatiquement>
////------------------------------------------------------------------------------

//namespace ATMTECH.FishingAtWork.WebSite {
    
    
//    public partial class OpenTrip {
        
//        /// <summary>
//        /// Contrôle pnlOpenTripGridView.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlOpenTripGridView;
        
//        /// <summary>
//        /// Contrôle lblTitleNewTrip.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblTitleNewTrip;
        
//        /// <summary>
//        /// Contrôle grdTripList.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Grille.GrilleAvance grdTripList;
        
//        /// <summary>
//        /// Contrôle pnlTripDetail.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlTripDetail;
        
//        /// <summary>
//        /// Contrôle Label1.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label Label1;
        
//        /// <summary>
//        /// Contrôle ddlSite.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlSite;
        
//        /// <summary>
//        /// Contrôle txtName.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtName;
        
//        /// <summary>
//        /// Contrôle txtDateStart.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.DateTextBoxAvance txtDateStart;
        
//        /// <summary>
//        /// Contrôle txtDateEnd.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.DateTextBoxAvance txtDateEnd;
        
//        /// <summary>
//        /// Contrôle txtWayPoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtWayPoint;
        
//        /// <summary>
//        /// Contrôle lblName.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblName;
        
//        /// <summary>
//        /// Contrôle googleMapThumbnailWindow.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.FishingAtWork.WebSite.UserControls.GoogleMap googleMapThumbnailWindow;
        
//        /// <summary>
//        /// Contrôle grdWaypointList.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Grille.GrilleAvance grdWaypointList;
        
//        /// <summary>
//        /// Contrôle btnSave.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnSave;
        
//        /// <summary>
//        /// Contrôle btnAddWaypoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnAddWaypoint;
        
//        /// <summary>
//        /// Contrôle btnCancel.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button btnCancel;
        
//        /// <summary>
//        /// Contrôle pnlEditWayPoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlEditWayPoint;
        
//        /// <summary>
//        /// Contrôle Label4.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label Label4;
        
//        /// <summary>
//        /// Contrôle ddlLure.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlLure;
        
//        /// <summary>
//        /// Contrôle ddlTechnique.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlTechnique;
        
//        /// <summary>
//        /// Contrôle ddlDeep.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlDeep;
        
//        /// <summary>
//        /// Contrôle ddlTimeStart.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlTimeStart;
        
//        /// <summary>
//        /// Contrôle ddlTimeEnd.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.ComboBoxAvance ddlTimeEnd;
        
//        /// <summary>
//        /// Contrôle txtLatitude.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtLatitude;
        
//        /// <summary>
//        /// Contrôle txtPixelX.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtPixelX;
        
//        /// <summary>
//        /// Contrôle txtLongitude.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtLongitude;
        
//        /// <summary>
//        /// Contrôle txtPixelY.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtPixelY;
        
//        /// <summary>
//        /// Contrôle Bouton1.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button Bouton1;
        
//        /// <summary>
//        /// Contrôle Bouton3.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button Bouton3;
        
//        /// <summary>
//        /// Contrôle Bouton2.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Button Bouton2;
        
//        /// <summary>
//        /// Contrôle pnlSelectWaypoint.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlSelectWaypoint;
        
//        /// <summary>
//        /// Contrôle lblTitleSelect.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblTitleSelect;
        
//        /// <summary>
//        /// Contrôle googleMap.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.FishingAtWork.WebSite.UserControls.GoogleMap googleMap;
//    }
//}
