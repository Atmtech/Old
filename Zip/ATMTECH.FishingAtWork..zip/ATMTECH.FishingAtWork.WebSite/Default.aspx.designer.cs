﻿////------------------------------------------------------------------------------
//// <généré automatiquement>
////     Ce code a été généré par un outil.
////
////     Les modifications apportées à ce fichier peuvent provoquer un comportement incorrect et seront perdues si
////     le code est régénéré.
//// </généré automatiquement>
////------------------------------------------------------------------------------

//namespace ATMTECH.FishingAtWork.WebSite {
    
    
//    public partial class Default1 {
        
//        /// <summary>
//        /// Contrôle pnlHomeUnlogged.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlHomeUnlogged;
        
//        /// <summary>
//        /// Contrôle pnlCurrentTrip.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlCurrentTrip;
        
//        /// <summary>
//        /// Contrôle lblTitleHomeInformation.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblTitleHomeInformation;
        
//        /// <summary>
//        /// Contrôle txtName.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtName;
        
//        /// <summary>
//        /// Contrôle txtSite.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtSite;
        
//        /// <summary>
//        /// Contrôle txtTotalPlayer.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.Web.Controls.Edition.TextBoxAvance txtTotalPlayer;
        
//        /// <summary>
//        /// Contrôle googleMap.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::ATMTECH.FishingAtWork.WebSite.UserControls.GoogleMap googleMap;
        
//        /// <summary>
//        /// Contrôle pnlNoTrip.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Panel pnlNoTrip;
        
//        /// <summary>
//        /// Contrôle lblNoTripAvailable.
//        /// </summary>
//        /// <remarks>
//        /// Champ généré automatiquement.
//        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
//        /// </remarks>
//        protected global::System.Web.UI.WebControls.Label lblNoTripAvailable;
//    }
//}
