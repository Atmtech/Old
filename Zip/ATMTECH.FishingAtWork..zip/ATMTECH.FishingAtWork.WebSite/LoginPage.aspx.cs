﻿using System;
using ATMTECH.FishingAtWork.WebSite.Base;

namespace ATMTECH.FishingAtWork.WebSite
{
    public partial class LoginPage : PageBaseFishingAtWork
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}