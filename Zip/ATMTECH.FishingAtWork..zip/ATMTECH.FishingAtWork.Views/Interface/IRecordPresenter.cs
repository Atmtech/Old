﻿using ATMTECH.Views.Interface;

namespace ATMTECH.FishingAtWork.Views.Interface
{
    public interface IRecordPresenter : IViewBase
    {
       

    }
}
