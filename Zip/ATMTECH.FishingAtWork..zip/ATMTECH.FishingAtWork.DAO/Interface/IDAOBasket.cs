﻿using System.Collections.Generic;
using ATMTECH.FishingAtWork.Entities;

namespace ATMTECH.FishingAtWork.DAO.Interface
{
    public interface IDAOBasket
    {
        int CreateBasket(Basket basket);
    }
}
