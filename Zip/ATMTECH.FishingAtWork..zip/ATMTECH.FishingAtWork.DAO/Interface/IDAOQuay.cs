﻿using ATMTECH.FishingAtWork.Entities;

namespace ATMTECH.FishingAtWork.DAO.Interface
{
    public interface IDAOQuay
    {
        Quay GetQuay(int id);
    }
}
