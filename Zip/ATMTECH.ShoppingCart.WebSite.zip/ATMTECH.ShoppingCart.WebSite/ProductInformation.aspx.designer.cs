﻿//------------------------------------------------------------------------------
// <généré automatiquement>
//     Ce code a été généré par un outil.
//
//     Les modifications apportées à ce fichier peuvent provoquer un comportement incorrect et seront perdues si
//     le code est régénéré.
// </généré automatiquement>
//------------------------------------------------------------------------------

namespace ATMTECH.ShoppingCart.WebSite {
    
    
    public partial class AddProductToBasket {
        
        /// <summary>
        /// Contrôle windowDisplayImage.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.FenetreDialogue windowDisplayImage;
        
        /// <summary>
        /// Contrôle imgDisplayImage.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Image imgDisplayImage;
        
        /// <summary>
        /// Contrôle titleProductInformation.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label titleProductInformation;
        
        /// <summary>
        /// Contrôle imgProductPrincipal.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ImageButton imgProductPrincipal;
        
        /// <summary>
        /// Contrôle DataListProductFile.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DataList DataListProductFile;
        
        /// <summary>
        /// Contrôle lblName.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.ContenuLabelAvance lblName;
        
        /// <summary>
        /// Contrôle lblIdent.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.ContenuLabelAvance lblIdent;
        
        /// <summary>
        /// Contrôle lblUnitPrice.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.ContenuLabelAvance lblUnitPrice;
        
        /// <summary>
        /// Contrôle lblCostPrice.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.ContenuLabelAvance lblCostPrice;
        
        /// <summary>
        /// Contrôle lblDisplayWeight.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblDisplayWeight;
        
        /// <summary>
        /// Contrôle lblWeight.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblWeight;
        
        /// <summary>
        /// Contrôle lblUnitWeight.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblUnitWeight;
        
        /// <summary>
        /// Contrôle lblProductCategoryDescription.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.ContenuLabelAvance lblProductCategoryDescription;
        
        /// <summary>
        /// Contrôle DataListStockNotOrderable.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DataList DataListStockNotOrderable;
        
        /// <summary>
        /// Contrôle DataListStockOrderable.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DataList DataListStockOrderable;
        
        /// <summary>
        /// Contrôle lblAddToBasketSucessfull.
        /// </summary>
        /// <remarks>
        /// Champ généré automatiquement.
        /// Pour modifier, déplacez la déclaration de champ du fichier de concepteur dans le fichier code-behind.
        /// </remarks>
        protected global::ATMTECH.Web.Controls.Affichage.TitreLabelAvance lblAddToBasketSucessfull;
    }
}
