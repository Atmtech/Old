﻿using System;
using ATMTECH.Entities;

namespace ATMTECH.ShoppingCart.ConvertImage
{
    [Serializable]
    public class Convertir : BaseEntity
    {
        public string ident { get; set; }
        public string url { get; set; }
    
    }
}
