﻿using System;
using ATMTECH.Entities;

namespace ATMTECH.SensArt.Entities
{
    [Serializable]
    public class Enchere : BaseEntity
    {
        public string Nom { get; set; }
       
    }
}
