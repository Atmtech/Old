﻿using System;

namespace ATMTECH.Tournoi.Entites
{
    public class Presence
    {
        public Equipe Equipe { get; set; }
        public DateTime Date { get; set; }
    }
}
